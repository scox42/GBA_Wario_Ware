//Sarah Cox (902958147)

#ifndef TITLE_BITMAP_H
#define TITLE_BITMAP_H
extern const unsigned short title[38400];
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160
#endif