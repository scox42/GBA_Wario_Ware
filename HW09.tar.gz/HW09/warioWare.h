//Sarah Cox (902958147)

void titleScreen();
//int level1(int pressed);
void gameOver();
void winScreen();
int playLevel2();
void makeCake();
void drawCake(int i);