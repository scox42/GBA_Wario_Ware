//Sarah Cox (902958147)

#ifndef FP_BITMAP_H
#define FP_BITMAP_H
extern const unsigned short fP[625];
#define FP_WIDTH 25
#define FP_HEIGHT 25
#endif