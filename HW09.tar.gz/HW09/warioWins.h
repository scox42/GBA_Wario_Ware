//Sarah Cox (902958147)

#ifndef WARIOWINS_BITMAP_H
#define WARIOWINS_BITMAP_H
extern const unsigned short warioWins[38400];
#define WARIOWINS_WIDTH 240
#define WARIOWINS_HEIGHT 160
#endif